# swmm-python


## Build Status
[![Build status](https://ci.appveyor.com/api/projects/status/g13vapirwhinmtob/branch/dev?svg=true)](https://ci.appveyor.com/project/michaeltryby/swmm-python/branch/dev)

[![Coverage Status](https://coveralls.io/repos/github/michaeltryby/swmm-python/badge.svg)](https://coveralls.io/github/michaeltryby/swmm-python)


## Contents
* swmm-python - SWIG based wrappers for the SWMM Toolkit and Output libraries.
* ...


## Build Notes
Note that swmm-python wraps the feature-wrapper branch of SWMM v5.1.12.  
